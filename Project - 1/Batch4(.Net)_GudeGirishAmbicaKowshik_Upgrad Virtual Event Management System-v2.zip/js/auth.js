function login(){

let email=document.getElementById("email").value;
let password=document.getElementById("password").value;

if(email==="admin@upgrad.com" && password==="12345"){

sessionStorage.setItem("loggedIn","true");
window.location.href="events.html";

}
else{

alert("Invalid Credentials");

}

}

function logout(){

sessionStorage.removeItem("loggedIn");
window.location.href="login.html";

}

function protectPage(){

if(sessionStorage.getItem("loggedIn")!=="true"){

alert("Unauthorized Access");
window.location.href="login.html";

}

}