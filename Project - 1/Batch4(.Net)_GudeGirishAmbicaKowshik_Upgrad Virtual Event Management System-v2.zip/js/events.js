let events=[];

function addEvent(){

let id=document.getElementById("id").value;
let name=document.getElementById("name").value;
let category=document.getElementById("category").value;
let date=document.getElementById("date").value;
let time=document.getElementById("time").value;
let url=document.getElementById("url").value;

let event={
id:id,
name:name,
category:category,
date:date,
time:time,
url:url
};

events.push(event);

displayEvents();

document.querySelector("form").reset();

}

function displayEvents(){

let output="";

events.forEach((e,index)=>{

output+=`

<div class="col-md-4">

<div class="card">

<div class="card-body">

<h5 class="card-title">${e.name}</h5>

<p>Event ID: ${e.id}</p>

<p>Category: ${e.category}</p>

<p>Date: ${e.date}</p>

<a href="${e.url}" target="_blank">Join Event</a>

<br><br>

<button class="btn btn-danger" onclick="deleteEvent(${index})">
Delete
</button>

</div>
</div>

</div>

`;

});

document.getElementById("eventList").innerHTML=output;

}

function deleteEvent(index){

events.splice(index,1);
displayEvents();

}

function searchEvent(){

let keyword=document.getElementById("search").value.toLowerCase();

let filtered=events.filter(e=>
e.id.includes(keyword) ||
e.name.toLowerCase().includes(keyword) ||
e.category.toLowerCase().includes(keyword)
);

let output="";

filtered.forEach((e,index)=>{

output+=`

<div class="col-md-4">

<div class="card">

<div class="card-body">

<h5>${e.name}</h5>

<p>ID: ${e.id}</p>

<p>${e.category}</p>

<p>${e.date}</p>

<a href="${e.url}" target="_blank">Join Event</a>

<br><br>

<button class="btn btn-danger" onclick="deleteEvent(${index})">
Delete
</button>

</div>
</div>

</div>

`;

});

document.getElementById("eventList").innerHTML=output;

}