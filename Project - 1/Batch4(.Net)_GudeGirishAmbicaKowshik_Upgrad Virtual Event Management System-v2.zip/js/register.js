function loadEvent(){

let params = new URLSearchParams(window.location.search);

let id = params.get("id");

if(id=="101"){

document.getElementById("eventId").innerText="1";
document.getElementById("eventName").innerText="AI Tech";
document.getElementById("eventCategory").innerText="Tech & Innovation";
document.getElementById("eventDate").innerText="20-06-2026";
document.getElementById("eventTime").innerText="10:00 AM";

}

if(id=="102"){

document.getElementById("eventId").innerText="2";
document.getElementById("eventName").innerText="3D Innovation";
document.getElementById("eventCategory").innerText="Industrial Event";
document.getElementById("eventDate").innerText="10-07-2026";
document.getElementById("eventTime").innerText="11:00 AM";

}

}

function registerEvent(){

let fname=document.getElementById("fname").value;
let lname=document.getElementById("lname").value;
let email=document.getElementById("email").value;

if(fname=="" || lname=="" || email==""){

alert("Please fill all fields");

}else{

alert("You are successfully registered to this event!");

document.getElementById("registerForm").reset();

}

}