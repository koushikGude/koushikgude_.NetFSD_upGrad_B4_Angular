function submitContact(){

let name=document.getElementById("name").value;
let email=document.getElementById("email").value;
let desc=document.getElementById("desc").value;

if(name==="" || email==="" || desc===""){

alert("Please fill all fields");

}
else{

alert("Message submitted successfully!");

document.getElementById("contactForm").reset();

}

}